i = 1
while i < 20:
  print(i)
  i += 1






"""
rows = []
with open("User2.csv") as file:
    csvreader = DictReader(file)
    header = next(csvreader)
    for row in csvreader:
        print(row["Name"])


users = {
1: {'name': '', 'mycountry': '', 'phone': '','pass':''},
2: {'name': '', 'mycountry': '', 'phone': '','pass':''},
3: {'name': '', 'mycountry': '', 'phone': '','pass':''},
4: {'name': '', 'mycountry': '', 'phone': '','pass':''},
          }

users[1]['name'] = input("Enter first User(1) name: ")
users[1]['mycountry'] = input('Enter Your Country Code for '+ users[1]['name'] +': +')
users[1]['phone'] = input("Enter Phone Number for "+users[1]['name']+":")
users[1]['pass'] = input('Enter Password for  '+ users[1]['name']+' > ')

#people[1]['name'] = input("Enter your name:")

print(users)
print(users[1]["phone"])


print(people[1]['name'])
print(people[1]['age'])
print(people[1]['sex'])




flow = 1
str = "pythonpool"

locals()[str] = 5000
print(pythonpool1)


    i = 1
    while i >=6:
      print(i)
      i -= 1
"""
